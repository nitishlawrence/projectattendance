import React, { useState } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isToday, isSameMonth } from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const events = [
    { date: new Date(2024, 2, 15), title: 'Team Meeting', type: 'meeting' },
    { date: new Date(2024, 2, 20), title: 'Project Deadline', type: 'deadline' },
    { date: new Date(2024, 2, 25), title: 'Training Session', type: 'training' },
  ];

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + 1)));
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() - 1)));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Calendar</h2>
        <div className="flex items-center space-x-4">
          <button
            onClick={prevMonth}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <h3 className="text-lg font-medium">
            {format(currentDate, 'MMMM yyyy')}
          </h3>
          <button
            onClick={nextMonth}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div
              key={day}
              className="bg-gray-50 py-2 text-center text-sm font-medium text-gray-500"
            >
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {daysInMonth.map((date) => {
            const dayEvents = events.filter(
              (event) =>
                format(event.date, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
            );

            return (
              <div
                key={date.toString()}
                className={`bg-white min-h-[100px] p-2 ${
                  !isSameMonth(date, currentDate)
                    ? 'bg-gray-50 text-gray-400'
                    : ''
                } ${isToday(date) ? 'bg-blue-50' : ''}`}
              >
                <span
                  className={`inline-flex items-center justify-center w-6 h-6 text-sm ${
                    isToday(date)
                      ? 'rounded-full bg-blue-600 text-white'
                      : 'text-gray-700'
                  }`}
                >
                  {format(date, 'd')}
                </span>
                <div className="mt-1 space-y-1">
                  {dayEvents.map((event, idx) => (
                    <div
                      key={idx}
                      className={`text-xs p-1 rounded ${
                        event.type === 'meeting'
                          ? 'bg-blue-100 text-blue-800'
                          : event.type === 'deadline'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-green-100 text-green-800'
                      }`}
                    >
                      {event.title}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}