import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Clock, MapPin, Camera } from 'lucide-react';
import CheckInModal from '../../components/attendance/CheckInModal';
import { checkIn, checkOut, getAttendanceHistory } from '../../services/api';
import toast from 'react-hot-toast';

export default function Attendance() {
  const [showModal, setShowModal] = useState(false);
  const [attendanceHistory, setAttendanceHistory] = useState([]);
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [checkInTime, setCheckInTime] = useState<Date | null>(null);
  const [hoursLogged, setHoursLogged] = useState<number | null>(null);

  useEffect(() => {
    loadAttendanceHistory();
  }, []);

  const loadAttendanceHistory = async () => {
    try {
      const { data } = await getAttendanceHistory();
      setAttendanceHistory(data);
      
      // Check today's status
      const today = new Date().toISOString().split('T')[0];
      const todayRecords = data.filter(
        (record: any) => record.date.split('T')[0] === today
      );
      
      const checkInRecord = todayRecords.find(
        (record: any) => record.type === 'check-in'
      );
      
      if (checkInRecord) {
        setIsCheckedIn(true);
        setCheckInTime(new Date(checkInRecord.date));
      }

      const checkOutRecord = todayRecords.find(
        (record: any) => record.type === 'check-out'
      );

      if (checkOutRecord && checkInRecord) {
        const hours = (new Date(checkOutRecord.date).getTime() - new Date(checkInRecord.date).getTime()) / (1000 * 60 * 60);
        setHoursLogged(hours);
      }
    } catch (error) {
      toast.error('Failed to load attendance history');
    }
  };

  const handleAttendance = async (data: any) => {
    try {
      if (!isCheckedIn) {
        await checkIn(data);
        setIsCheckedIn(true);
        setCheckInTime(new Date());
      } else {
        const response = await checkOut(data);
        setHoursLogged(response.data.hoursLogged);
        setIsCheckedIn(false);
      }
      setShowModal(false);
      loadAttendanceHistory();
      toast.success(`Successfully ${isCheckedIn ? 'checked out' : 'checked in'}`);
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to process attendance');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Attendance</h2>
        <button
          onClick={() => setShowModal(true)}
          className={`btn-primary flex items-center gap-2 ${
            hoursLogged !== null ? 'opacity-50 cursor-not-allowed' : ''
          }`}
          disabled={hoursLogged !== null}
        >
          <Clock className="h-5 w-5" />
          {isCheckedIn ? 'Check Out' : 'Check In'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Today's Status</h3>
          <div className="space-y-4">
            {isCheckedIn && (
              <>
                <div className="flex items-center text-green-600">
                  <Clock className="h-5 w-5 mr-2" />
                  <span>Checked in at {checkInTime?.toLocaleTimeString()}</span>
                </div>
                {hoursLogged !== null && (
                  <div className="text-blue-600">
                    Hours Logged: {hoursLogged.toFixed(2)} hours
                  </div>
                )}
              </>
            )}
            {!isCheckedIn && !hoursLogged && (
              <div className="flex items-center text-yellow-600">
                <Clock className="h-5 w-5 mr-2" />
                <span>Not checked in yet</span>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {attendanceHistory.slice(0, 5).map((record: any) => (
              <div key={record._id} className="flex items-center justify-between py-2 border-b">
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-gray-400 mr-2" />
                  <div>
                    <span className="text-sm text-gray-600">
                      {format(new Date(record.date), 'MMM dd, yyyy HH:mm')}
                    </span>
                    <span className="ml-2 px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                      {record.type}
                    </span>
                  </div>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>
                    {record.location.lat.toFixed(6)}, {record.location.lng.toFixed(6)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showModal && (
        <CheckInModal
          onClose={() => setShowModal(false)}
          onSubmit={handleAttendance}
          isCheckOut={isCheckedIn}
        />
      )}
    </div>
  );
}