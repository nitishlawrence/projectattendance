import React, { useState, useEffect } from 'react';
import { Clock, Calendar, FileText, CheckCircle } from 'lucide-react';
import { getAttendanceHistory, getLeaveHistory } from '../../services/api';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

export default function EmployeeDashboard() {
  const [stats, setStats] = useState({
    hoursToday: 0,
    attendanceRate: 0,
    leaveBalance: 12,
    pendingLeaves: 0
  });
  const [recentAttendance, setRecentAttendance] = useState([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [attendanceRes, leaveRes] = await Promise.all([
        getAttendanceHistory(),
        getLeaveHistory()
      ]);

      // Calculate hours logged today
      const today = new Date().toISOString().split('T')[0];
      const todayRecord = attendanceRes.data.find(
        record => record.date.startsWith(today)
      );
      const hoursToday = todayRecord?.hoursLogged || 0;

      // Calculate attendance rate (last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      const recentRecords = attendanceRes.data.filter(
        record => new Date(record.date) >= thirtyDaysAgo
      );
      const presentDays = recentRecords.filter(record => record.hoursLogged >= 7).length;
      const attendanceRate = (presentDays / 20) * 100; // Assuming 20 working days

      // Count pending leaves
      const pendingLeaves = leaveRes.data.filter(
        leave => leave.status === 'pending'
      ).length;

      setStats({
        hoursToday,
        attendanceRate,
        leaveBalance: 12 - leaveRes.data.filter(
          leave => leave.status === 'approved'
        ).length,
        pendingLeaves
      });

      setRecentAttendance(attendanceRes.data.slice(0, 5));
    } catch (error) {
      toast.error('Failed to load dashboard data');
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="bg-white overflow-hidden rounded-lg shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Hours Today
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stats.hoursToday.toFixed(2)}h
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden rounded-lg shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Attendance Rate
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stats.attendanceRate.toFixed(1)}%
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden rounded-lg shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Calendar className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Leave Balance
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stats.leaveBalance} days
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden rounded-lg shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <FileText className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Pending Leaves
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stats.pendingLeaves}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">
          Recent Attendance
        </h3>
        <div className="space-y-4">
          {recentAttendance.map((record, index) => (
            <div key={index} className="flex items-center justify-between py-2 border-b">
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-gray-400 mr-2" />
                <div>
                  <span className="text-sm text-gray-600">
                    {format(new Date(record.date), 'MMM dd, yyyy')}
                  </span>
                  <span className={`ml-2 px-2 py-1 text-xs rounded-full ${
                    record.hoursLogged >= 7
                      ? 'bg-green-100 text-green-800'
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {record.hoursLogged >= 7 ? 'Present' : 'Half Day'}
                  </span>
                </div>
              </div>
              <div className="text-sm text-gray-500">
                {record.hoursLogged.toFixed(2)} hours
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}