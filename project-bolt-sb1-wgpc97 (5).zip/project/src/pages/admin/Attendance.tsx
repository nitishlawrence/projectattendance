import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Download, Search, Calendar } from 'lucide-react';
import { getAttendanceHistory, getAllEmployeesAttendance } from '../../services/api';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';

export default function AdminAttendance() {
  const [attendanceData, setAttendanceData] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState('all');

  useEffect(() => {
    loadAttendanceData();
  }, [startDate, endDate]);

  const loadAttendanceData = async () => {
    try {
      const { data } = await getAllEmployeesAttendance(startDate || endDate ? {
        startDate,
        endDate: endDate || startDate
      } : null);
      
      const processedData = data.map(record => ({
        ...record,
        hoursLogged: record.checkIn && record.checkOut ? 
          (new Date(record.checkOut).getTime() - new Date(record.checkIn).getTime()) / (1000 * 60 * 60) :
          null
      }));
      
      setAttendanceData(processedData);
    } catch (error) {
      toast.error('Failed to load attendance data');
    }
  };

  const downloadReport = () => {
    const reportData = attendanceData.map(record => ({
      'Date': format(new Date(record.date), 'yyyy-MM-dd'),
      'Employee Name': record.user.name,
      'Employee ID': record.user.employeeId,
      'Check In': record.checkIn ? format(new Date(record.checkIn), 'HH:mm:ss') : '-',
      'Check Out': record.checkOut ? format(new Date(record.checkOut), 'HH:mm:ss') : '-',
      'Hours Logged': record.hoursLogged ? record.hoursLogged.toFixed(2) : '-',
      'Location': record.location?.address || '-',
      'Status': record.hoursLogged >= 7 ? 'Present' : record.checkIn ? 'Half Day' : 'Absent'
    }));

    const ws = XLSX.utils.json_to_sheet(reportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Attendance');
    XLSX.writeFile(wb, `attendance-report-${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
  };

  const filteredData = attendanceData.filter(record => {
    const matchesSearch = record.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         record.user.employeeId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesEmployee = selectedEmployee === 'all' || record.user._id === selectedEmployee;
    return matchesSearch && matchesEmployee;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Attendance Records</h2>
        <button onClick={downloadReport} className="btn-primary flex items-center gap-2">
          <Download className="h-5 w-5" />
          Download Report
        </button>
      </div>

      <div className="bg-white shadow-sm rounded-lg">
        <div className="p-4 border-b border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search by name or ID..."
                className="input-field pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-gray-400" />
              <input
                type="date"
                className="input-field"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
              <span>to</span>
              <input
                type="date"
                className="input-field"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Employee
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Check In
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Check Out
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Hours Logged
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Location
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredData.map((record, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {format(new Date(record.date), 'dd/MM/yyyy')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{record.user.name}</div>
                    <div className="text-sm text-gray-500">{record.user.employeeId}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {record.checkIn ? format(new Date(record.checkIn), 'HH:mm:ss') : '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {record.checkOut ? format(new Date(record.checkOut), 'HH:mm:ss') : '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {record.hoursLogged ? `${record.hoursLogged.toFixed(2)} hrs` : '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      record.hoursLogged >= 7
                        ? 'bg-green-100 text-green-800'
                        : record.checkIn
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {record.hoursLogged >= 7 ? 'Present' : record.checkIn ? 'Half Day' : 'Absent'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {record.location?.address || '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}