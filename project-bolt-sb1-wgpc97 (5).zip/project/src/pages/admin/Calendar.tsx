import React, { useState, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isToday, isSameMonth, parseISO } from 'date-fns';
import { ChevronLeft, ChevronRight, Users } from 'lucide-react';
import { getAllEmployeesAttendance, getAllEmployees, getLeaveHistory } from '../../services/api';
import toast from 'react-hot-toast';

export default function AdminCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedEmployee, setSelectedEmployee] = useState('all');
  const [employees, setEmployees] = useState([]);
  const [attendanceData, setAttendanceData] = useState({});
  const [leaveData, setLeaveData] = useState([]);

  useEffect(() => {
    loadEmployees();
    loadMonthData();
  }, [currentDate, selectedEmployee]);

  const loadEmployees = async () => {
    try {
      const { data } = await getAllEmployees();
      setEmployees(data);
    } catch (error) {
      toast.error('Failed to load employees');
    }
  };

  const loadMonthData = async () => {
    try {
      const startDate = format(startOfMonth(currentDate), 'yyyy-MM-dd');
      const endDate = format(endOfMonth(currentDate), 'yyyy-MM-dd');

      const [attendanceRes, leaveRes] = await Promise.all([
        getAllEmployeesAttendance({ startDate, endDate }),
        getLeaveHistory()
      ]);

      // Process attendance data
      const attendanceMap = {};
      attendanceRes.data.forEach(record => {
        const date = format(parseISO(record.date), 'yyyy-MM-dd');
        if (!attendanceMap[date]) {
          attendanceMap[date] = {};
        }
        attendanceMap[date][record.user._id] = record;
      });
      setAttendanceData(attendanceMap);

      // Process leave data
      setLeaveData(leaveRes.data);
    } catch (error) {
      toast.error('Failed to load calendar data');
    }
  };

  const getAttendanceStatus = (date, employeeId) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    const record = attendanceData[dateStr]?.[employeeId];
    
    // Check if on leave
    const onLeave = leaveData.some(leave => {
      const leaveStart = parseISO(leave.startDate);
      const leaveEnd = parseISO(leave.endDate);
      return leave.user === employeeId && 
             date >= leaveStart &&
             date <= leaveEnd &&
             leave.status === 'approved';
    });

    if (onLeave) return 'leave';
    if (!record) return isSameMonth(date, currentDate) ? 'absent' : '';
    if (record.hoursLogged >= 7) return 'present';
    return 'half-day';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'present':
        return 'bg-green-100 text-green-800';
      case 'half-day':
        return 'bg-yellow-100 text-yellow-800';
      case 'absent':
        return 'bg-red-100 text-red-800';
      case 'leave':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-500';
    }
  };

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Attendance Calendar</h2>
        <div className="flex items-center space-x-4">
          <select
            className="input-field"
            value={selectedEmployee}
            onChange={(e) => setSelectedEmployee(e.target.value)}
          >
            <option value="all">All Employees</option>
            {employees.map((emp) => (
              <option key={emp._id} value={emp._id}>
                {emp.name}
              </option>
            ))}
          </select>
          <button
            onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() - 1)))}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <h3 className="text-lg font-medium">
            {format(currentDate, 'MMMM yyyy')}
          </h3>
          <button
            onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + 1)))}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div
              key={day}
              className="bg-gray-50 py-2 text-center text-sm font-medium text-gray-500"
            >
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {daysInMonth.map((date) => {
            const employeesToShow = selectedEmployee === 'all'
              ? employees
              : employees.filter((emp) => emp._id === selectedEmployee);

            return (
              <div
                key={date.toString()}
                className={`bg-white min-h-[120px] p-2 ${
                  !isSameMonth(date, currentDate) ? 'bg-gray-50' : ''
                } ${isToday(date) ? 'bg-blue-50' : ''}`}
              >
                <span className={`inline-flex items-center justify-center w-6 h-6 text-sm ${
                  isToday(date) ? 'rounded-full bg-blue-600 text-white' : 'text-gray-700'
                }`}>
                  {format(date, 'd')}
                </span>
                <div className="mt-1 space-y-1 max-h-[100px] overflow-y-auto">
                  {employeesToShow.map((emp) => {
                    const status = getAttendanceStatus(date, emp._id);
                    if (!status) return null;
                    return (
                      <div
                        key={emp._id}
                        className={`text-xs p-1 rounded flex items-center justify-between ${getStatusColor(status)}`}
                      >
                        <span className="truncate">{emp.name}</span>
                        <span className="capitalize ml-1">{status}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}