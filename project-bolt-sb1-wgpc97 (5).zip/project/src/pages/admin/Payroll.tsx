import React, { useState, useEffect } from 'react';
import { Download, Search } from 'lucide-react';
import { getAllEmployees } from '../../services/api';
import toast from 'react-hot-toast';

export default function Payroll() {
  const [employees, setEmployees] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    try {
      const { data } = await getAllEmployees();
      setEmployees(data);
    } catch (error) {
      toast.error('Failed to load employees');
    }
  };

  const generatePayslip = (employee: any) => {
    // Calculate basic components
    const basicSalary = parseFloat(employee.salary);
    const hra = basicSalary * 0.4;
    const da = basicSalary * 0.1;
    const conveyance = 1600;
    const medical = 1250;
    const special = basicSalary * 0.15;

    // Calculate deductions
    const pf = Math.min(basicSalary * 0.12, 1800);
    const professionalTax = 200;
    const incomeTax = basicSalary * 0.1; // Simplified calculation

    // Calculate total earnings and deductions
    const totalEarnings = basicSalary + hra + da + conveyance + medical + special;
    const totalDeductions = pf + professionalTax + incomeTax;
    const netPay = totalEarnings - totalDeductions;

    const payslipHTML = `
      <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h2>SALARY SLIP</h2>
          <p>For the month of ${new Date(selectedYear, selectedMonth).toLocaleString('default', { month: 'long' })} ${selectedYear}</p>
        </div>

        <div style="margin-bottom: 20px;">
          <h3>Employee Details</h3>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 5px;">Name: ${employee.name}</td>
              <td style="padding: 5px;">Employee ID: ${employee.employeeId}</td>
            </tr>
            <tr>
              <td style="padding: 5px;">Department: ${employee.department}</td>
              <td style="padding: 5px;">Position: ${employee.position}</td>
            </tr>
          </table>
        </div>

        <div style="display: flex; justify-content: space-between;">
          <div style="width: 48%;">
            <h3>Earnings</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 5px;">Basic Salary</td>
                <td style="padding: 5px; text-align: right;">₹${basicSalary.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px;">HRA</td>
                <td style="padding: 5px; text-align: right;">₹${hra.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px;">DA</td>
                <td style="padding: 5px; text-align: right;">₹${da.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px;">Conveyance</td>
                <td style="padding: 5px; text-align: right;">₹${conveyance.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px;">Medical</td>
                <td style="padding: 5px; text-align: right;">₹${medical.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px;">Special Allowance</td>
                <td style="padding: 5px; text-align: right;">₹${special.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px; font-weight: bold;">Total Earnings</td>
                <td style="padding: 5px; text-align: right; font-weight: bold;">₹${totalEarnings.toFixed(2)}</td>
              </tr>
            </table>
          </div>

          <div style="width: 48%;">
            <h3>Deductions</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 5px;">PF</td>
                <td style="padding: 5px; text-align: right;">₹${pf.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px;">Professional Tax</td>
                <td style="padding: 5px; text-align: right;">₹${professionalTax.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px;">Income Tax</td>
                <td style="padding: 5px; text-align: right;">₹${incomeTax.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 5px; font-weight: bold;">Total Deductions</td>
                <td style="padding: 5px; text-align: right; font-weight: bold;">₹${totalDeductions.toFixed(2)}</td>
              </tr>
            </table>
          </div>
        </div>

        <div style="margin-top: 20px; text-align: right;">
          <h3>Net Pay: ₹${netPay.toFixed(2)}</h3>
        </div>
      </div>
    `;

    const blob = new Blob([payslipHTML], { type: 'text/html' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payslip-${employee.name}-${selectedMonth + 1}-${selectedYear}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const filteredEmployees = employees.filter((emp: any) =>
    emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Payroll Management</h2>
      </div>

      <div className="bg-white shadow-sm rounded-lg">
        <div className="p-4 border-b border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search employees..."
                className="input-field pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <select
                className="input-field"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              >
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i} value={i}>
                    {new Date(2000, i).toLocaleString('default', { month: 'long' })}
                  </option>
                ))}
              </select>
              <select
                className="input-field"
                value={selectedYear}
                onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              >
                {Array.from({ length: 5 }, (_, i) => {
                  const year = new Date().getFullYear() - 2 + i;
                  return (
                    <option key={year} value={year}>
                      {year}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Employee
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Department
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Position
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Basic Salary
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredEmployees.map((employee: any) => (
                <tr key={employee._id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{employee.name}</div>
                    <div className="text-sm text-gray-500">{employee.email}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {employee.department}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {employee.position}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ₹{parseFloat(employee.salary).toLocaleString('en-IN')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => generatePayslip(employee)}
                      className="text-blue-600 hover:text-blue-900 flex items-center gap-1 ml-auto"
                    >
                      <Download className="h-4 w-4" />
                      Generate Payslip
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}