import React, { useEffect, useState } from 'react';
import { Users, Clock, Calendar, AlertTriangle } from 'lucide-react';
import { getAllEmployees, getAttendanceHistory } from '../../services/api';
import AttendanceMap from '../../components/attendance/AttendanceMap';
import toast from 'react-hot-toast';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalEmployees: 0,
    presentToday: 0,
    onLeave: 0,
    lateArrivals: 0,
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [employeesRes, attendanceRes] = await Promise.all([
        getAllEmployees(),
        getAttendanceHistory(new Date().toISOString())
      ]);

      const presentEmployees = new Set(
        attendanceRes.data
          .filter((record: any) => record.type === 'check-in')
          .map((record: any) => record.user._id)
      );

      setStats({
        totalEmployees: employeesRes.data.length,
        presentToday: presentEmployees.size,
        onLeave: 0, // Will be updated when leave system is implemented
        lateArrivals: 0, // Will be calculated based on check-in time
      });
    } catch (error) {
      toast.error('Failed to load dashboard data');
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="bg-white overflow-hidden rounded-lg shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Employees
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stats.totalEmployees}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden rounded-lg shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Clock className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Present Today
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stats.presentToday}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden rounded-lg shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Calendar className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    On Leave
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stats.onLeave}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden rounded-lg shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Late Arrivals
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stats.lateArrivals}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">
          Live Employee Locations
        </h3>
        <AttendanceMap />
      </div>
    </div>
  );
}