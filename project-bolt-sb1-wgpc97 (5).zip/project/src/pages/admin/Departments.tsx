import React, { useState } from 'react';
import { Building2, Plus, Edit, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Departments() {
  const [departments] = useState([
    { id: 1, name: 'Engineering', employeeCount: 45, manager: 'John Smith' },
    { id: 2, name: 'Marketing', employeeCount: 23, manager: 'Sarah Johnson' },
    { id: 3, name: 'Sales', employeeCount: 34, manager: 'Mike Wilson' },
    { id: 4, name: 'Human Resources', employeeCount: 12, manager: 'Emily Brown' },
  ]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Departments</h2>
        <button className="btn-primary flex items-center gap-2">
          <Plus className="h-5 w-5" />
          Add Department
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departments.map((dept) => (
          <div key={dept.id} className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-start">
              <div className="flex items-center">
                <Building2 className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <h3 className="text-lg font-semibold text-gray-900">{dept.name}</h3>
                  <p className="text-sm text-gray-500">{dept.employeeCount} Employees</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <button className="p-1 text-gray-400 hover:text-blue-600">
                  <Edit className="h-5 w-5" />
                </button>
                <button className="p-1 text-gray-400 hover:text-red-600">
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-100">
              <p className="text-sm text-gray-600">
                <span className="font-medium">Manager:</span> {dept.manager}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}