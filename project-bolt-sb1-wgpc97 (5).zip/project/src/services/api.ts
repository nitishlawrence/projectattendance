import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
});

// Add token to requests if it exists
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auth
export const login = async (email: string, password: string) => {
  const response = await api.post('/auth/login', { email, password });
  return response.data;
};

// Attendance
export const checkIn = async (data: { photo: string; location: { lat: number; lng: number } }) => {
  const response = await api.post('/attendance/check-in', data);
  return response.data;
};

export const checkOut = async (data: { photo: string; location: { lat: number; lng: number } }) => {
  const response = await api.post('/attendance/check-out', data);
  return response.data;
};

export const getAttendanceHistory = async (startDate?: string, endDate?: string) => {
  const params = new URLSearchParams();
  if (startDate) params.append('startDate', startDate);
  if (endDate) params.append('endDate', endDate);
  
  const response = await api.get(`/attendance/history?${params}`);
  return response.data;
};

export const getEmployeeLocations = async () => {
  const response = await api.get('/attendance/locations');
  return response.data;
};

export const getAllEmployeesAttendance = async (date: string) => {
  const response = await api.get(`/attendance/all?date=${date}`);
  return response.data;
};

// Employee Management
export const getAllEmployees = async () => {
  const response = await api.get('/employees');
  return response.data;
};

export const createEmployee = async (employeeData: any) => {
  const response = await api.post('/employees', employeeData);
  return response.data;
};

export const updateEmployee = async (id: string, employeeData: any) => {
  const response = await api.patch(`/employees/${id}`, employeeData);
  return response.data;
};

export const deleteEmployee = async (id: string) => {
  const response = await api.delete(`/employees/${id}`);
  return response.data;
};

// Leave Management
export const applyLeave = async (leaveData: any) => {
  const response = await api.post('/leave/apply', leaveData);
  return response.data;
};

export const getLeaveHistory = async () => {
  const response = await api.get('/leave/history');
  return response.data;
};

// For admin only
export const approveLeave = async (leaveId: string) => {
  const response = await api.patch(`/leave/${leaveId}/approve`);
  return response.data;
};

export const rejectLeave = async (leaveId: string) => {
  const response = await api.patch(`/leave/${leaveId}/reject`);
  return response.data;
};