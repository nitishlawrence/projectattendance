import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  Clock,
  DollarSign,
  Settings,
  ClipboardList
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function Sidebar() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const navItems = [
    {
      label: 'Dashboard',
      icon: LayoutDashboard,
      to: isAdmin ? '/admin/dashboard' : '/employee/dashboard',
    },
    ...(isAdmin ? [
      { label: 'Employees', icon: Users, to: '/admin/employees' },
      { label: 'Payroll', icon: DollarSign, to: '/admin/payroll' },
      { label: 'Leave Management', icon: ClipboardList, to: '/admin/leave-management' },
    ] : []),
    { label: 'Attendance', icon: Clock, to: `/${user?.role}/attendance` },
    { label: 'Calendar', icon: Calendar, to: `/${user?.role}/calendar` },
    { label: 'Settings', icon: Settings, to: `/${user?.role}/settings` },
  ];

  return (
    <aside className="w-64 bg-white shadow-sm min-h-screen">
      <div className="h-full px-3 py-4">
        <div className="mb-8 px-4">
          <h2 className="text-lg font-semibold text-gray-900">EMS Portal</h2>
        </div>
        
        <nav className="space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center px-4 py-2 text-sm font-medium rounded-lg ${
                  isActive
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-50'
                }`
              }
            >
              <item.icon className="mr-3 h-5 w-5" />
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </aside>
  );
}