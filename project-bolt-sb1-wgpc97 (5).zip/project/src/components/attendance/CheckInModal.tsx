import React, { useRef, useState, useCallback, useEffect } from 'react';
import Webcam from 'react-webcam';
import { X, Camera, MapPin } from 'lucide-react';
import toast from 'react-hot-toast';
import { MapContainer, TileLayer, Marker, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

interface CheckInModalProps {
  onClose: () => void;
  onSubmit: (data: { photo: string; location: { lat: number; lng: number } }) => void;
  isCheckOut?: boolean;
}

function LocationMarker({ position, setLocation }: any) {
  const map = useMap();
  
  useEffect(() => {
    map.flyTo(position, map.getZoom());
  }, [position, map]);

  return position ? <Marker position={position} /> : null;
}

export default function CheckInModal({ onClose, onSubmit, isCheckOut = false }: CheckInModalProps) {
  const webcamRef = useRef<Webcam>(null);
  const [photo, setPhoto] = useState<string | null>(null);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showMap, setShowMap] = useState(false);

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      setPhoto(imageSrc);
    }
  }, [webcamRef]);

  const getLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const newLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          setLocation(newLocation);
          setShowMap(true);
        },
        (error) => {
          toast.error('Unable to get location');
          console.error(error);
        }
      );
    } else {
      toast.error('Geolocation is not supported by your browser');
    }
  };

  const handleSubmit = async () => {
    if (!photo || !location) {
      toast.error('Please capture photo and allow location access');
      return;
    }

    setIsLoading(true);
    try {
      await onSubmit({ photo, location });
      onClose();
    } catch (error) {
      toast.error(`Failed to ${isCheckOut ? 'check out' : 'check in'}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-900">
            {isCheckOut ? 'Check Out' : 'Check In'}
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="relative">
            {!photo ? (
              <Webcam
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                className="w-full rounded-lg"
              />
            ) : (
              <img src={photo} alt="Captured" className="w-full rounded-lg" />
            )}
          </div>

          <div className="flex justify-center space-x-4">
            <button onClick={capture} className="btn-primary flex items-center gap-2">
              <Camera className="h-5 w-5" />
              {photo ? 'Retake' : 'Capture'}
            </button>

            <button
              onClick={getLocation}
              className={`btn-primary flex items-center gap-2 ${
                location ? 'bg-green-600' : ''
              }`}
            >
              <MapPin className="h-5 w-5" />
              {location ? 'Location Captured' : 'Get Location'}
            </button>
          </div>

          {showMap && location && (
            <div className="relative h-48 z-10 rounded-lg overflow-hidden">
              <MapContainer
                center={[location.lat, location.lng]}
                zoom={15}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                />
                <LocationMarker position={[location.lat, location.lng]} />
              </MapContainer>
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={!photo || !location || isLoading}
            className="w-full btn-primary mt-4"
          >
            {isLoading ? 'Processing...' : isCheckOut ? 'Submit Check-out' : 'Submit Check-in'}
          </button>
        </div>
      </div>
    </div>
  );
}