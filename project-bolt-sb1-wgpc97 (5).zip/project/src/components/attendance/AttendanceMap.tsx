import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { Icon } from 'leaflet';
import { getEmployeeLocations } from '../../services/api';
import toast from 'react-hot-toast';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icon
delete (Icon.Default.prototype as any)._getIconUrl;
Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface Location {
  user: {
    _id: string;
    name: string;
  };
  location: {
    lat: number;
    lng: number;
  };
  date: string;
}

export default function AttendanceMap() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [center, setCenter] = useState<[number, number]>([0, 0]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLocations();
    getCurrentLocation();
  }, []);

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCenter([position.coords.latitude, position.coords.longitude]);
        },
        () => {
          toast.error('Unable to get current location');
          setCenter([51.505, -0.09]); // Default to London
        }
      );
    }
  };

  const loadLocations = async () => {
    try {
      const { data } = await getEmployeeLocations();
      setLocations(data);
      setLoading(false);
    } catch (error) {
      toast.error('Failed to load employee locations');
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading map...</div>;
  }

  return (
    <MapContainer
      center={center}
      zoom={13}
      style={{ height: '500px', width: '100%', borderRadius: '0.5rem' }}
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      />
      
      {locations.map((loc) => (
        <Marker
          key={`${loc.user._id}-${loc.date}`}
          position={[loc.location.lat, loc.location.lng]}
        >
          <Popup>
            <div className="p-2">
              <h3 className="font-semibold">{loc.user.name}</h3>
              <p className="text-sm text-gray-600">
                Check-in time: {new Date(loc.date).toLocaleString()}
              </p>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}