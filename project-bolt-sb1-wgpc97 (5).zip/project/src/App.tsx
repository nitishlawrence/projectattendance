import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import LoginForm from './components/LoginForm';
import DashboardLayout from './components/layouts/DashboardLayout';
import AdminDashboard from './pages/admin/Dashboard';
import EmployeeDashboard from './pages/employee/Dashboard';
import AdminAttendance from './pages/admin/Attendance';
import EmployeeAttendance from './pages/employee/Attendance';
import AdminCalendar from './pages/admin/Calendar';
import EmployeeCalendar from './pages/employee/Calendar';
import Settings from './pages/employee/Settings';
import Employees from './pages/admin/Employees';
import Payroll from './pages/admin/Payroll';
import LeaveManagement from './pages/admin/LeaveManagement';
import { AuthProvider } from './context/AuthContext';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<LoginForm />} />
          <Route path="/admin" element={<DashboardLayout />}>
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="employees" element={<Employees />} />
            <Route path="attendance" element={<AdminAttendance />} />
            <Route path="calendar" element={<AdminCalendar />} />
            <Route path="payroll" element={<Payroll />} />
            <Route path="leave-management" element={<LeaveManagement />} />
          </Route>
          <Route path="/employee" element={<DashboardLayout />}>
            <Route path="dashboard" element={<EmployeeDashboard />} />
            <Route path="attendance" element={<EmployeeAttendance />} />
            <Route path="calendar" element={<EmployeeCalendar />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Routes>
        <Toaster position="top-right" />
      </Router>
    </AuthProvider>
  );
}

export default App;