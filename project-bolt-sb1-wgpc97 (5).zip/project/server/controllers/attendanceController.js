import Attendance from '../models/Attendance.js';
import { catchAsync } from '../utils/catchAsync.js';
import { reverseGeocode } from '../utils/geocoding.js';

export const checkIn = catchAsync(async (req, res) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const existingCheckIn = await Attendance.findOne({
    user: req.user._id,
    date: { $gte: today },
    type: 'check-in'
  });

  if (existingCheckIn) {
    return res.status(400).json({
      status: 'error',
      message: 'Already checked in today'
    });
  }

  // Get address from coordinates
  const address = await reverseGeocode(req.body.location.lat, req.body.location.lng);
  
  const attendance = await Attendance.create({
    user: req.user._id,
    type: 'check-in',
    photo: req.body.photo,
    location: {
      ...req.body.location,
      address
    },
    date: new Date()
  });

  res.status(201).json({
    status: 'success',
    data: attendance
  });
});

export const checkOut = catchAsync(async (req, res) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const checkIn = await Attendance.findOne({
    user: req.user._id,
    date: { $gte: today },
    type: 'check-in'
  });

  if (!checkIn) {
    return res.status(400).json({
      status: 'error',
      message: 'No check-in found for today'
    });
  }

  // Remove any previous check-out for today
  await Attendance.deleteMany({
    user: req.user._id,
    date: { $gte: today },
    type: 'check-out'
  });

  const address = await reverseGeocode(req.body.location.lat, req.body.location.lng);

  const checkOut = await Attendance.create({
    user: req.user._id,
    type: 'check-out',
    photo: req.body.photo,
    location: {
      ...req.body.location,
      address
    },
    date: new Date()
  });

  // Calculate hours logged
  const hoursLogged = (checkOut.date - checkIn.date) / (1000 * 60 * 60);

  res.status(201).json({
    status: 'success',
    data: {
      ...checkOut.toObject(),
      hoursLogged
    }
  });
});