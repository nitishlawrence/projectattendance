import User from '../models/User.js';
import { catchAsync } from '../utils/catchAsync.js';

export const getAllEmployees = catchAsync(async (req, res) => {
  const employees = await User.find()
    .select('-password')
    .sort('-createdAt');

  res.status(200).json({
    status: 'success',
    results: employees.length,
    data: employees
  });
});

export const createEmployee = catchAsync(async (req, res) => {
  const newEmployee = await User.create({
    ...req.body,
    employeeId: `EMP${Date.now().toString().slice(-6)}`
  });

  // Remove password from response
  newEmployee.password = undefined;

  res.status(201).json({
    status: 'success',
    data: newEmployee
  });
});

export const updateEmployee = catchAsync(async (req, res) => {
  const employee = await User.findByIdAndUpdate(
    req.params.id,
    req.body,
    {
      new: true,
      runValidators: true
    }
  ).select('-password');

  if (!employee) {
    return res.status(404).json({
      status: 'error',
      message: 'Employee not found'
    });
  }

  res.status(200).json({
    status: 'success',
    data: employee
  });
});

export const deleteEmployee = catchAsync(async (req, res) => {
  const employee = await User.findByIdAndDelete(req.params.id);

  if (!employee) {
    return res.status(404).json({
      status: 'error',
      message: 'Employee not found'
    });
  }

  res.status(204).json({
    status: 'success',
    data: null
  });
});