import Leave from '../models/Leave.js';
import { catchAsync } from '../utils/catchAsync.js';

export const applyLeave = catchAsync(async (req, res) => {
  const leave = await Leave.create({
    user: req.user._id,
    ...req.body
  });

  res.status(201).json({
    status: 'success',
    data: leave
  });
});

export const getLeaveHistory = catchAsync(async (req, res) => {
  const leaves = await Leave.find({ user: req.user._id })
    .sort('-createdAt');

  res.status(200).json({
    status: 'success',
    data: leaves
  });
});

export const approveLeave = catchAsync(async (req, res) => {
  const leave = await Leave.findByIdAndUpdate(
    req.params.id,
    {
      status: 'approved',
      approvedBy: req.user._id,
      approvedAt: Date.now()
    },
    { new: true }
  );

  if (!leave) {
    return res.status(404).json({
      status: 'error',
      message: 'Leave application not found'
    });
  }

  res.status(200).json({
    status: 'success',
    data: leave
  });
});

export const rejectLeave = catchAsync(async (req, res) => {
  const leave = await Leave.findByIdAndUpdate(
    req.params.id,
    {
      status: 'rejected',
      approvedBy: req.user._id,
      approvedAt: Date.now()
    },
    { new: true }
  );

  if (!leave) {
    return res.status(404).json({
      status: 'error',
      message: 'Leave application not found'
    });
  }

  res.status(200).json({
    status: 'success',
    data: leave
  });
});