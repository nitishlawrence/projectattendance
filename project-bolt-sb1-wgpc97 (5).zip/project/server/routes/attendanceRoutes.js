import express from 'express';
import {
  checkIn,
  checkOut,
  getAttendanceHistory,
  getEmployeeLocations,
  getAllEmployeesAttendance
} from '../controllers/attendanceController.js';
import { protect, restrictTo } from '../middleware/auth.js';

const router = express.Router();

router.use(protect);

router.post('/check-in', checkIn);
router.post('/check-out', checkOut);
router.get('/history', getAttendanceHistory);
router.get('/locations', getEmployeeLocations);
router.get('/all', restrictTo('admin'), getAllEmployeesAttendance);

export default router;