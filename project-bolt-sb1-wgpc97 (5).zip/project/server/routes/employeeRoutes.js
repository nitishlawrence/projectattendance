import express from 'express';
import {
  getAllEmployees,
  createEmployee,
  updateEmployee,
  deleteEmployee
} from '../controllers/employeeController.js';

const router = express.Router();

router
  .route('/')
  .get(getAllEmployees)
  .post(createEmployee);

router
  .route('/:id')
  .patch(updateEmployee)
  .delete(deleteEmployee);

export default router;