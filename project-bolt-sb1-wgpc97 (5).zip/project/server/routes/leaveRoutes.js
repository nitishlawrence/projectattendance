import express from 'express';
import {
  applyLeave,
  getLeaveHistory,
  approveLeave,
  rejectLeave
} from '../controllers/leaveController.js';
import { protect, restrictTo } from '../middleware/auth.js';

const router = express.Router();

router.use(protect);

router.post('/apply', applyLeave);
router.get('/history', getLeaveHistory);

// Admin only routes
router.patch('/:id/approve', restrictTo('admin'), approveLeave);
router.patch('/:id/reject', restrictTo('admin'), rejectLeave);

export default router;